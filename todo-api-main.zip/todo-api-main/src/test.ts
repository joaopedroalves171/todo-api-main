import { CreateTaskService } from './services/create-task-service'

const service = new CreateTaskService()

service.exec('Fazer café')