import { app } from './app'

app.listen(8000, () => {
    console.log('SERVER UP')
})
